<!--
  Please read the contibuting guide before you submit a pull request
  https://github.com/fomantic/Fomantic-UI/blob/master/CONTRIBUTING.md
-->

## Description

## Testcase
<!-- Fork https://jsfiddle.net/31d6y7mn -->

## Screenshot (when possible)
![]()

## Closes
#222 #333 #444
